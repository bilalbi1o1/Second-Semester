﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace AllTasks
{
    class Program
    {
        class Students
        {
            public string name;
            public int roll_no;
            public float cgpa;
            public char isHostalide;
            public string department;
        }
        class Products
        {
            public  int id;
            public string name;
            public float price;
            public string category;
            public string brandName;
            public string country;
        }
        class Credentials
        { 
            public string usernames;
            public string passwords;
        }

        static void Main(string[] args)
        {
            //Task1();
            //Task2();
            //Task3();
            //Task4();//challenge Task 1
            Task5();//challenge Task 2

        }
        
        static void Task1()
        {
            //First Object
            Students st1 = new Students();
            st1.name = "Bilal";
            st1.roll_no = 170;
            st1.cgpa = 3.5F;
            Console.WriteLine("Name : {0}  Roll no : {1}  CGPA : {2}", st1.name, st1.roll_no, st1.cgpa);

            //Second Object
            Students st2 = new Students();
            st2.name = "Burhan";
            st2.roll_no = 191;
            st2.cgpa = 3.6F;
            Console.WriteLine("Name : {0}  Roll no : {1}  CGPA : {2}", st2.name, st2.roll_no, st2.cgpa);

            Console.Read();
        }
        static void Task2()
        {
            //Input Data in objects
            Students st3 = new Students();
            Console.Write("Enter Name : ");
            st3.name = Console.ReadLine();
            Console.Write("Enter Roll no : ");
            st3.roll_no = int.Parse(Console.ReadLine());
            Console.Write("Enter CGPA : ");
            st3.cgpa = float.Parse(Console.ReadLine());
            Console.WriteLine("Name : {0}  Roll no : {1}  CGPA : {2}", st3.name, st3.roll_no, st3.cgpa);

            Console.Read();
        }
        
        static void Task3()
        {
            Students[] s = new Students[10];
            char option;
            int count = 0;
            do
            {
                option = menu();
                if (option == '1')
                {
                    s[count] = addStudents();
                    count++;
                }
                else if (option == '2')
                {
                    viewStudents(s, count);
                }
                else if (option == '3')
                {
                    topStudents(s, count);
                }
                else
                {
                    Console.WriteLine("Invalid option");
                }
            } while (option != '4');
            Console.WriteLine("Press Enter to Exit..");
            Console.Read();
        }
        static char menu()
        {
            Console.Clear();
            char choice;
            Console.WriteLine("1 for adding a student");
            Console.WriteLine("2 to view all students");
            Console.WriteLine("3 for Top three students");
            choice = char.Parse(Console.ReadLine());
            return choice;
        }
        static Students addStudents()
        {
            Console.Clear();
            Students s1 = new Students();
            Console.Write("Enter Name : ");
            s1.name = Console.ReadLine();
            Console.Write("Enter Roll no : ");
            s1.roll_no = int.Parse(Console.ReadLine());
            Console.Write("Enter CGPA : ");
            s1.cgpa = float.Parse(Console.ReadLine());
            Console.Write("Enter Department : ");
            s1.department = Console.ReadLine();
            Console.Write("Is Hostalide ( y || n ) : ");
            s1.isHostalide = char.Parse(Console.ReadLine());

            return s1;
        }
        static void viewStudents(Students[] s,int count)
        {
            Console.Clear();
            for (int i = 0; i < count; i++)
            {
                Console.WriteLine("Name : {0}  Roll no : {1}  CGPA : {2}  Department : {3}  IsHostalide : {4}", s[i].name, s[i].roll_no, s[i].cgpa, s[i].department, s[i].isHostalide);
            }
            Console.WriteLine("Press any key to continue.. ");
            Console.ReadKey();
        }
        static void topStudents(Students[] s,int count)
        {
            Console.Clear();
            if (count == 0)
            {
                Console.WriteLine("No record Present");
            }
            else if (count == 1)
            {
                viewStudents(s, 1);
            }
            else if (count == 2)
            {
                for (int i = 0; i < 2; i++)
                {
                    int index = largest(s, i, count);
                    Students temp = s[index];
                    s[index] = s[i];
                    s[i] = temp;
                }
                viewStudents(s, 2);
            }
            else
            {
                for (int i = 0; i < 3; i++)
                {
                    int index = largest(s, i, count);
                    Students temp = s[index];
                    s[index] = s[i];
                    s[i] = temp;
                }
                viewStudents(s, 3);
            }

        }
        static int largest(Students[] s, int start,int end)
        {
            int index = start;
            float large = s[start].cgpa;
            for (int i = 0; i < end; i++)
            {
                if (large < s[start].cgpa)
                {
                    large = s[start].cgpa;
                    index = i;
                }

            }
            return index;
        }

        static void Task4()//challege Task 1
        {
            Products[] p = new Products[10];
            char option;

            int count = 0;
            float worth;
            do
            {
                option = productsMenu();
                if (option == '1')
                {
                    p[count] = addProducts();
                    count++;
                }
                else if (option == '2')
                {
                    showProducts(p, count);
                }
                else if (option == '3')
                {
                    worth = totalWorth(p, count);
                    Console.WriteLine("Total worth is : {0}",worth);
                    Console.Read();
                }
                else
                {
                    Console.WriteLine("Invalid option");
                }
            } while (option != '4');
            Console.WriteLine("Press Enter to Exit..");
            Console.ReadKey();

        }
        static char productsMenu()
        {
            Console.Clear();
            char choice;
            Console.WriteLine("1 for adding a product");
            Console.WriteLine("2 to show all products");
            Console.WriteLine("3 for total store worth");
            choice = char.Parse(Console.ReadLine());
            return choice;
        }
        static Products addProducts()
        {
            Console.Clear();
            Products p = new Products();
            Console.Write("Enter ID : ");
            p.id = int.Parse(Console.ReadLine());
            Console.Write("Enter Name : ");
            p.name = Console.ReadLine();
            Console.Write("Enter Price : ");
            p.price = float.Parse(Console.ReadLine());
            Console.Write("Enter Category : ");
            p.category = Console.ReadLine();
            Console.Write("Enter Brand Name : ");
            p.brandName = Console.ReadLine();
            Console.Write("Enter Country ");
            p.country = Console.ReadLine();

            return p;
        }
        static void showProducts(Products[] p, int count)
        {
            Console.Clear();
            for (int i = 0; i < count; i++)
            {
                Console.WriteLine("ID : {0}  Name : {1}  Price : {2}  Category : {3}  Brand Name : {4}  Country : {5}", p[i].id, p[i].name, p[i].price, p[i].category, p[i].brandName,p[i].country);
            }
            Console.WriteLine("Press any key to continue.. ");
            Console.ReadKey();
        }
        static float totalWorth(Products[] p, int count)
        {
            float total = 0;
            for (int i = 0; i < count; i++)
            {
                total = total + p[i].price;
            }
            return total;
        }

               static void Task5()//challege Task 2
        {
            string path = "SignIn.txt";
            string name;
            string password;

            Credentials[] users = new Credentials[10];

            int option;
            int count = 0;
            do
            {

                count = readData(path, users);
                Console.Clear();
                option = singInMenu();
                Console.Clear();

                if (option == 1)
                {
                    Console.WriteLine("Enter Name: ");
                    name = Console.ReadLine();
                    Console.WriteLine("Enter Password: ");
                    password = Console.ReadLine();
                    signIn(users, name, password, count);
                }
                else
                {
                    Console.WriteLine("Enter New Name: ");
                     name = Console.ReadLine();
                    Console.WriteLine("Enter New Password: ");
                     password = Console.ReadLine();
                    signUp(path, name, password);
                }
            } while (option < 3);
                Console.Read();
        }
        
        static int singInMenu()
        {
            int option;
            Console.WriteLine("1. SignIn");
            Console.WriteLine("2. SignUp");
            Console.WriteLine("Enter Option : ");
            option = int.Parse(Console.ReadLine());
            return option;
        }
        static int readData(string path, Credentials[] users)
    {
        int x = 0;
        StreamReader file = new StreamReader(path);
        string record;
        Credentials cred = new Credentials();
            while ((record = file.ReadLine()) != null)
            {
                cred.usernames = parseData(record, 1);
                cred.passwords = parseData(record, 2);

                users[x] = cred;
            x++;
            }
        file.Close();
        Console.ReadKey();

            return x;
        

    }
        static string parseData(string record, int field)
    {
        int comma = 1;
        string item = "";
        for (int x = 0; x < record.Length; x++)
        {
            if (record[x] == ',')
            {
                comma++;
            }
            else if (comma == field)
            {
                item = item + record[x];
            }
        }
        return item;
    }
        static void signIn(Credentials[] users, string name, string password,int count)
        {
            bool flag = false;

            for (int i = 0; i < count; i++)
            {
                if (name == users[i].usernames && password == users[i].passwords)
                {
                    Console.WriteLine("Valid User");
                    flag = true;
                    break;
                }
            }
            if (flag == false)
                Console.WriteLine("Invalid User");

            Console.ReadKey();
        }
        static void signUp(string path, string n, string p)
        {
            StreamWriter file = new StreamWriter(path, true);
            file.WriteLine(n + "," + p);
            file.Flush();
            file.Close();
        }
    }
}

