﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace TrainManagementSystem
{
    class Program
    {
        ////////////////////////////////////////Global Variables/////////////////////////////////////////////////
         static int total = 100;

         static int cycle = 0; // use to manage parallel arrays data of train

        // all data related to trains is stored in given these arrays
        static string[] train = new string[100];
        static string[] type = new string[100];
        static string[] ticketPrice = new string[100];
        static string[] departureTime = new string[100];
        static string[] compartments = new string[100];
        static string[] ticketsDiscount = new string[100];
        static string[] luggageTax = new string[100];
        static string[] starting = new string[100];
        static string[] ending = new string[100];

        static int count = 0; // use to manage parallel arrays data of users

        // all data related to user accounts is stored in given these arrays
        static string[] names = new string[100];
        static string[] passwords = new string[100];
        static string[] role = new string[100];

        static int Main(string[] args)
        {
            loadingTrainData();
            loadingAccounts();

            string option;
            string checkName;
            string checkPassword;
            string checkRole;
            string trainCheck;
            string classCheck;
            string ticketPriceCheck;
            string departureTimeCheck;
            string compartmentsCheck;
            string ticketsDiscountCheck;
            string luggageTaxCheck;
            string startingCheck;
            string endingCheck;
            string preClass;
            string currentClass;
            string preTime;
            string currentTime;
            string prePrice;
            string currentPrice;
            string preCompartment;
            string currentCompartment;
            string preLuggage;
            string currentLuggage;
            string preDiscount;
            string currentDiscount;

            string choice;
            string destinationInput;
            string startingInput;
            string receivedAmount;
            int totalBill;

            int intFlag;
            char check1 = '0';

            bool flag;
            bool commaFlag;
            int flagSearch;

            while (true)
            {
                panel();
                option = menu();

                flag = menuValidity(option);
                while (flag == false) // force user to enter valid input
                {
                    gotoxy(20, 26);
                    Console.Write("Enter a valid option!!");
                    gotoxy(40, 24);
                    Console.Write("                         ");
                    gotoxy(20, 24);
                    Console.Write("Enter your choice : ");
                    option = Console.ReadLine();
                    flag = menuValidity(option);
                }

                if (option == "1")
                {
                    panel();

                    gotoxy(70, 18);
                    Console.Write("*****Login Menu*****");
                    gotoxy(20, 20);
                    Console.Write("Enter your name :");
                    checkName = Console.ReadLine();
                    gotoxy(20, 21);
                    Console.Write("Enter your password :");
                    checkPassword = Console.ReadLine();

                    intFlag = loginValidity(checkName, checkPassword);

                    if (intFlag == -1)
                    {
                        gotoxy(20, 24);
                        Console.Write(" Information you have entered is invalid!!");
                        Console.ReadKey();
                        continue;
                    }
                    else
                    {
                        if (role[intFlag] == "ADMIN") // all of admin's functionalities are in this loop
                        {
                            while (true)
                            {
                                option = adminMenu();

                                check1 = adminMenuValidity(option);
                                option = conversion(option);
                                if (option == "RETURN") // logout condition
                                {
                                    gotoxy(20, 32);
                                    Console.Write("Press any key to continue... ");
                                    break;
                                }
                                else if (check1 == ',')
                                {
                                    gotoxy(20, 33);
                                    Console.Write("Enter a valid number!! ");
                                    continue;
                                }

                                if (check1 == '1') // train adding section
                                {
                                    trainCheck = addTrain();

                                    flag = isTrainNameValid(trainCheck);
                                    commaFlag = commaCheck(trainCheck);
                                    if (trainCheck.Length < 3)
                                    {
                                        gotoxy(20, 31);
                                        Console.Write("Train name should atleast have 3 characters!!");
                                        Console.ReadKey();
                                        continue;
                                    }
                                    if (flag == false)
                                    {
                                        gotoxy(20, 31);
                                        Console.Write("Enter a different train name this one is already taken!!");
                                        Console.ReadKey();
                                        continue;
                                    }
                                    else if (commaFlag == false)
                                    {
                                        gotoxy(20, 31);
                                        Console.Write("comma can not be used in username!!");
                                        Console.ReadKey();
                                        continue;
                                    }

                                    gotoxy(20, 32);
                                    Console.Write("business,economical or firstClass");
                                    gotoxy(20, 23);
                                    Console.Write("Enter the class of the new train :");
                                    classCheck = Console.ReadLine();
                                    classCheck = conversion(classCheck);
                                    flag = isTrainTypeValid(classCheck);

                                    if (flag == false)
                                    {
                                        gotoxy(20, 31);
                                        Console.Write("Enter a valid train class!!");
                                        Console.ReadKey();
                                        continue;
                                    }
                                    else
                                    {
                                        gotoxy(20, 32);
                                        Console.Write("                                                   ");
                                    }

                                    gotoxy(20, 32);
                                    Console.Write("Minimum 500 and Maximum 5000");
                                    gotoxy(20, 24);
                                    Console.Write("Enter the price of ticket of the new train :");
                                    ticketPriceCheck = Console.ReadLine();
                                    intFlag = isTrainPriceValid(ticketPriceCheck);
                                    if (intFlag <= 0)
                                    {
                                        gotoxy(20, 31);
                                        Console.Write("Enter a valid price!!");
                                        Console.ReadKey();
                                        continue;
                                    }
                                    else
                                    {
                                        gotoxy(20, 32);
                                        Console.Write("                                                       ");
                                    }

                                    gotoxy(20, 32);
                                    Console.Write("Correct format is hours:minutes and max time is 23:59");
                                    gotoxy(20, 25);
                                    Console.Write("Enter the time of departure of the new train :");
                                    departureTimeCheck = Console.ReadLine();
                                    flag = isDepartureTimeValid(departureTimeCheck);
                                    if (flag == false)
                                    {
                                        gotoxy(20, 31);
                                        Console.Write("Time might be invalid or format might be incorrect!!");
                                        Console.ReadKey();
                                        continue;
                                    }
                                    else
                                    {
                                        gotoxy(20, 32);
                                        Console.Write("                                                       ");
                                    }

                                    gotoxy(20, 32);
                                    Console.Write("Minimum 10 and Maximum 20");
                                    gotoxy(20, 26);
                                    Console.Write("Enter the number of compartments of the new train :");
                                    compartmentsCheck = Console.ReadLine();
                                    flag = isTrainCompartmentValid(compartmentsCheck);
                                    if (flag == false)
                                    {
                                        gotoxy(20, 31);
                                        Console.Write("Enter a valid compartment number !!");
                                        Console.ReadKey();
                                        continue;
                                    }
                                    else
                                    {
                                        gotoxy(20, 32);
                                        Console.Write("                                                       ");
                                    }

                                    gotoxy(20, 32);
                                    Console.Write("Minimum 1 and Maximum 9");
                                    gotoxy(20, 27);
                                    Console.Write("Enter the number of tickets to avail the discount :");
                                    ticketsDiscountCheck = Console.ReadLine();
                                    flag = isTrainDiscountValid(ticketsDiscountCheck);
                                    if (flag == false)
                                    {
                                        gotoxy(20, 31);
                                        Console.Write("Enter a valid number !!");

                                        Console.ReadKey();
                                        continue;
                                    }
                                    else
                                    {
                                        gotoxy(20, 32);
                                        Console.Write("                                                   ");
                                    }

                                    gotoxy(20, 32);
                                    Console.Write("Minimum 1 and Maximum 30");
                                    gotoxy(20, 28);
                                    Console.Write("Enter the minimum weight(kg) of luggage to apply tax :");
                                    luggageTaxCheck = Console.ReadLine();
                                    flag = isTrainLuggageValid(luggageTaxCheck);
                                    if (flag == false)
                                    {
                                        gotoxy(20, 31);
                                        Console.Write("Enter a valid number !!");
                                        Console.ReadKey();
                                        continue;
                                    }
                                    else
                                    {
                                        gotoxy(20, 32);
                                        Console.Write("                                                               ");
                                    }

                                    gotoxy(20, 32);
                                    Console.Write("Lahore,Karachi,Islamabad,Multan,Sialkot,Peshawar,Haiderabad,Gujranwala or Quetta");
                                    gotoxy(20, 29);
                                    Console.Write("Enter the starting point of the train :");
                                    startingCheck = Console.ReadLine();
                                    startingCheck = conversion(startingCheck);
                                    flag = isTrainStartValid(startingCheck);
                                    if (flag == false)
                                    {
                                        gotoxy(20, 31);
                                        Console.Write("Enter a valid Name !!");
                                        Console.ReadKey();
                                        continue;
                                    }
                                    else
                                    {
                                        gotoxy(20, 32);
                                        Console.Write("                                                                                            ");
                                    }

                                    gotoxy(20, 34);
                                    Console.Write("Lahore,Karachi,Islamabad,Multan,Sialkot,Peshawar,Haiderabad,Gujranwala or Quetta");
                                    gotoxy(20, 35);
                                    Console.Write("Note : Starting point must not match the destination");
                                    gotoxy(20, 30);
                                    Console.Write("Enter the destination of the train :");
                                    endingCheck = Console.ReadLine();
                                    endingCheck = conversion(endingCheck);
                                    flag = isTrainEndValid(startingCheck, endingCheck);
                                    if (flag == false)
                                    {
                                        gotoxy(20, 33);
                                        Console.Write("Enter a valid Name !!");
                                        Console.ReadKey();
                                        continue;
                                    }
                                    else
                                    {
                                        gotoxy(20, 34);
                                        Console.Write("                                                                                       ");
                                        gotoxy(20, 35);
                                        Console.Write("                                                                                         ");
                                    }

                                    train[cycle] = trainCheck;
                                    type[cycle] = classCheck;
                                    ticketPrice[cycle] = ticketPriceCheck;
                                    departureTime[cycle] = departureTimeCheck;
                                    compartments[cycle] = compartmentsCheck;
                                    ticketsDiscount[cycle] = ticketsDiscountCheck;
                                    luggageTax[cycle] = luggageTaxCheck;
                                    starting[cycle] = startingCheck;
                                    ending[cycle] = endingCheck;

                                    storeTrainData(trainCheck, classCheck, ticketPriceCheck, departureTimeCheck, compartmentsCheck, ticketsDiscountCheck, luggageTaxCheck, startingCheck, endingCheck);

                                    cycle = cycle + 1;
                                    gotoxy(20, 36);
                                    Console.Write("New train has been added!");
                                    gotoxy(20, 31);
                                    Console.Write("                                                           ");
                                    Console.ReadKey();
                                }
                                else if (check1 == '2') // train searching section
                                {
                                    trainCheck = searchTrain();

                                    flagSearch = searchTrainValidity(trainCheck);
                                    if (flagSearch == -1)
                                    {
                                        gotoxy(20, 25);
                                        Console.Write("The train you have entered doesn't exist !");
                                        Console.ReadKey();
                                        continue;
                                    }

                                    DisplaySearchTrain(flagSearch);
                                }
                                else if (check1 == '3') // train deleting section
                                {
                                    trainCheck = removeTrain();

                                    intFlag = searchTrainValidity(trainCheck);
                                    if (intFlag == -1)
                                    {
                                        gotoxy(20, 25);
                                        Console.Write("The train you have entered doesn't exist !");
                                        Console.ReadKey();
                                        continue;
                                    }

                                    gotoxy(20, 31);
                                    Console.Write("Tne train named " + trainCheck + " has been deleted successfully!!");
                                    removeTrainExecute(trainCheck);
                                    Console.ReadKey();
                                }
                                else if (check1 == '4') // class changing section
                                {
                                    trainCheck = classTrain();

                                    intFlag = searchTrainValidity(trainCheck);
                                    if (intFlag == -1)
                                    {
                                        gotoxy(20, 30);
                                        Console.Write("The train you have entered doesn't exist !!");
                                        Console.ReadKey();
                                        continue;
                                    }

                                    preClass = previousClass(trainCheck);
                                    gotoxy(20, 23);
                                    Console.Write("The previous class of train is " + preClass);
                                    gotoxy(20, 32);
                                    Console.Write("BUSINESS,ECONOMICAL or FIRSTCLASS");
                                    gotoxy(20, 24);
                                    Console.Write("Enter the new class for the train ");
                                    currentClass = Console.ReadLine();
                                    currentClass = conversion(currentClass);
                                    flag = compareClasses(currentClass, preClass);
                                    if (flag == false)
                                    {
                                        gotoxy(20, 31);
                                        Console.Write("Enter a valid train class!!");
                                        gotoxy(20, 33);
                                        Console.Write("Note : new class must not match the previous class!");
                                        Console.ReadKey();
                                        continue;
                                    }

                                    classAssign(trainCheck, currentClass);
                                    gotoxy(20, 30);
                                    Console.Write("Class of the train has been updated successfully!!");
                                    Console.ReadKey();
                                }
                                else if (check1 == '5') // departing time changing section
                                {
                                    trainCheck = departure();

                                    intFlag = searchTrainValidity(trainCheck);
                                    if (intFlag == -1)
                                    {
                                        gotoxy(20, 25);
                                        Console.Write("The train you have entered doesn't exist :");
                                        Console.ReadKey();
                                        continue;
                                    }

                                    preTime = previousTime(trainCheck);
                                    gotoxy(20, 32);
                                    Console.Write("Correct format is hours:minutes and max time is 23:59");
                                    gotoxy(20, 23);
                                    Console.Write("The previous departure time of this train is " + preTime);
                                    gotoxy(20, 24);
                                    Console.Write("Enter the new departure time for the train :");
                                    currentTime = Console.ReadLine();
                                    flag = isDepartureTimeValid(currentTime);
                                    if (currentTime == preTime)
                                    {
                                        gotoxy(20, 31);
                                        Console.Write("Enter a valid time for departure!!");
                                        gotoxy(20, 32);
                                        Console.Write("Previous Time must not match the new time");
                                        Console.ReadKey();
                                        continue;
                                    }
                                    else if (flag == false)
                                    {
                                        gotoxy(20, 31);
                                        Console.Write("Enter a valid time for departure!!");
                                        Console.ReadKey();
                                        continue;
                                    }

                                    timeAssign(trainCheck, currentTime);
                                    gotoxy(20, 30);
                                    Console.Write("Departure time of the train has been updated successfully!!");
                                    Console.ReadKey();
                                }
                                else if (check1 == '6') // ticket price changing section
                                {
                                    trainCheck = price();

                                    intFlag = searchTrainValidity(trainCheck);
                                    if (intFlag == -1)
                                    {
                                        gotoxy(20, 25);
                                        Console.Write("The train you have entered doesn't exist :");
                                        Console.ReadKey();
                                        continue;
                                    }

                                    prePrice = previousPrice(trainCheck);
                                    gotoxy(20, 23);
                                    Console.Write("The previous ticket price of this train is " + prePrice);
                                    gotoxy(20, 24);
                                    Console.Write("Enter the new ticket price for the train :");
                                    currentPrice = Console.ReadLine();
                                    intFlag = isTrainPriceValid(currentPrice);
                                    if (currentPrice == prePrice)
                                    {
                                        gotoxy(20, 31);
                                        Console.Write("Previous Price must not match the new price");
                                        Console.ReadKey();
                                        continue;
                                    }
                                    else if (intFlag == -1)
                                    {
                                        gotoxy(20, 31);
                                        Console.Write("Enter a valid ticket price!!");
                                        Console.ReadKey();
                                        continue;
                                    }

                                    priceAssign(trainCheck, currentPrice);
                                    gotoxy(20, 30);
                                    Console.Write("Ticket price of the train has been updated successfully!!");
                                    Console.ReadKey();
                                }
                                else if (check1 == '7') // number of compartments changing section
                                {
                                    trainCheck = compartment();

                                    intFlag = searchTrainValidity(trainCheck);
                                    if (intFlag == -1)
                                    {
                                        gotoxy(20, 25);
                                        Console.Write("The train you have entered doesn't exist !");
                                        Console.ReadKey();
                                        continue;
                                    }

                                    preCompartment = previousCompartment(trainCheck);
                                    gotoxy(20, 23);
                                    Console.Write("The previous number of compartments of this train is " + preCompartment);
                                    gotoxy(20, 24);
                                    Console.Write("Enter the new number of compartments for the train :");
                                    currentCompartment = Console.ReadLine();
                                    flag = isTrainCompartmentValid(currentCompartment);
                                    if (currentCompartment == preCompartment)
                                    {
                                        gotoxy(20, 31);
                                        Console.Write("Enter a valid number for compartment !!");
                                        gotoxy(20, 32);
                                        Console.Write("New number of compartments must not match the previous number of compartments");
                                        Console.ReadKey();
                                        continue;
                                    }
                                    else if (flag == false)
                                    {
                                        gotoxy(20, 31);
                                        Console.Write("Enter a valid number for compartment !!");
                                        Console.ReadKey();
                                        continue;
                                    }

                                    compartmentAssign(trainCheck, currentCompartment);
                                    gotoxy(20, 30);
                                    Console.Write("Compartment numbers of the train has been updated successfully!!");
                                    Console.ReadKey();
                                }
                                else if (check1 == '8') // luggage limit for applying tax changing section
                                {

                                    trainCheck = luggage();

                                    intFlag = searchTrainValidity(trainCheck);
                                    if (intFlag == -1)
                                    {
                                        gotoxy(20, 25);
                                        Console.Write("The train you have entered doesn't exist !");
                                        Console.ReadKey();
                                        continue;
                                    }

                                    preLuggage = previousLuggage(trainCheck);
                                    gotoxy(20, 30);
                                    Console.Write("Minimum 1 kg and Maximum 30 kg");
                                    gotoxy(20, 23);
                                    Console.Write("The previous amount of luggage for applying tax of this train is " + preLuggage);
                                    gotoxy(20, 24);
                                    Console.Write("Enter the new amount of luggage for applying tax for the train :");
                                    currentLuggage = Console.ReadLine();
                                    flag = isTrainLuggageValid(currentLuggage);
                                    if (currentLuggage == preLuggage)
                                    {
                                        gotoxy(20, 31);
                                        Console.Write("New amount of luggage for applying tax must not match the previous amount of luggage for applying tax!!");
                                        Console.ReadKey();
                                        continue;
                                    }
                                    else if (flag == false)
                                    {
                                        gotoxy(20, 31);
                                        Console.Write("Enter a valid number !!");
                                        Console.ReadKey();
                                        continue;
                                    }

                                    luggageAssign(trainCheck, currentLuggage);
                                    gotoxy(20, 30);
                                    Console.Write("Luggage amount for applying Tax of the train has been updated successfully!!");
                                    Console.ReadKey();
                                }
                                else if (check1 == '9') // changing number of tickets to give discount section
                                {

                                    trainCheck = discount();

                                    intFlag = searchTrainValidity(trainCheck);
                                    if (intFlag == -1)
                                    {
                                        gotoxy(20, 25);
                                        Console.Write("The train you have entered doesn't exist :");
                                        Console.ReadKey();
                                        continue;
                                    }

                                    preDiscount = previousDiscount(trainCheck);
                                    gotoxy(20, 32);
                                    Console.Write("Minimum 1 and Maximum 9");
                                    gotoxy(20, 23);
                                    Console.Write("The previous number of tickets of this train to avail discount is " + preDiscount);
                                    gotoxy(20, 24);
                                    Console.Write("Enter the new number of tickets to avail discount for the train :");
                                    currentDiscount = Console.ReadLine();
                                    flag = isTrainDiscountValid(currentDiscount);
                                    if (currentDiscount == preDiscount)
                                    {
                                        gotoxy(20, 31);
                                        Console.Write("New tickets number must not match the previous ticket numbers");
                                        Console.ReadKey();
                                        continue;
                                    }
                                    else if (flag == false)
                                    {
                                        gotoxy(20, 31);
                                        Console.Write("Enter a valid number of tickets for availing discount !!");
                                        Console.ReadKey();
                                        continue;
                                    }

                                    discountAssign(trainCheck, preDiscount);
                                    gotoxy(20, 30);
                                    Console.Write("Number of tickets to avail discount of the train has been updated successfully!!");
                                    Console.ReadKey();
                                }
                                else // travelling history view of all users
                                {
                                    panel();
                                    gotoxy(70, 18);
                                    Console.Write("Travelling History");
                                    gotoxy(0, 20);
                                    displayUserTravelingHistory();
                                }
                            }
                            Console.ReadKey();
                        }

                        else
                        {

                            while (true)
                            {
                                choice = user();

                                if (choice != "0" && choice != "1" && choice != "2")
                                {
                                    gotoxy(20, 26);
                                    Console.Write("Enter a valid choice!!");
                                    Console.ReadKey();
                                    continue;
                                }
                                if (choice == "0") // logout condition
                                    break;
                                else if (choice == "2") // to view my own travelling history
                                {
                                    panel();
                                    gotoxy(70, 18);
                                    Console.Write("Travelling History");
                                    gotoxy(0, 20);
                                    displaySpecificUserTravelingHistory(checkName);
                                    continue;
                                }

                                startingInput = startingPoint();
                                flag = isTrainStartValid(startingInput);
                                if (flag == false)
                                {
                                    gotoxy(20, 22);
                                    Console.Write(" Invalid input!!");
                                    Console.ReadKey();
                                    continue;
                                }

                                destinationInput = destinationPoint();
                                flag = isTrainEndValid(startingInput, destinationInput);
                                if (flag == false)
                                {
                                    gotoxy(20, 30);
                                    Console.Write(" Invalid input!!");
                                    gotoxy(20, 32);
                                    Console.Write("Note: starting point and destination must not match");
                                    Console.ReadKey();
                                    continue;
                                }
                                gotoxy(20, 31);
                                Console.Write("                                                                                  ");

                                flag = availableTrains(startingInput, destinationInput);
                                if (flag == false)
                                {
                                    gotoxy(20, 30);
                                    Console.Write("Press Enter to return");
                                    Console.ReadKey();
                                    continue;
                                }

                                gotoxy(20, 23);
                                Console.Write("Enter the name of train in which you want to travel :");
                                trainCheck = Console.ReadLine();
                                trainCheck = conversion(trainCheck);

                                flag = isSelectedTrainValid(trainCheck, startingInput, destinationInput);
                                if (flag == false)
                                {
                                    gotoxy(20, 24);
                                    Console.Write("The train you have entered is not available or exist!");
                                    Console.ReadKey();
                                    continue;
                                }

                                while (true)
                                {
                                    bool check = false;
                                    panel();

                                    gotoxy(70, 18);
                                    Console.Write("*****Passener's Menu*****");

                                    intFlag = currentTrainIndex(trainCheck);
                                    gotoxy(20, 25);
                                    Console.Write("Purchase " + ticketsDiscount[intFlag] + " tickets to get 30 percent discount");
                                    gotoxy(20, 26);
                                    Console.Write("Minimum 1 and Maximum 9 tickets can be purchased from 1 user account");
                                    gotoxy(20, 27);
                                    Console.Write("Enter 'return' to go back to the main screen of user panel");
                                    gotoxy(20, 20);
                                    Console.Write("Enter how many tickets you want to purchase :");
                                    ticketsDiscountCheck = Console.ReadLine();
                                    flag = isTrainDiscountValid(ticketsDiscountCheck);
                                    ticketsDiscountCheck = conversion(ticketsDiscountCheck);
                                    if (ticketsDiscountCheck == "RETURN") // to go back to previous options
                                        break;
                                    if (flag == false)
                                    {
                                        gotoxy(20, 31);
                                        Console.Write(" Invalid input !!");
                                        Console.ReadKey();
                                        continue;
                                    }
                                    gotoxy(20, 32);
                                    Console.Write("                                                                        ");
                                    while (true)
                                    {
                                        panel();

                                        gotoxy(70, 18);
                                        Console.Write("*****Passener's Menu*****");

                                        gotoxy(20, 26);
                                        Console.Write("Your choice should not exceed total number of compartments of selected train!!");
                                        gotoxy(20, 25);
                                        Console.Write("Total compartments of the selected train are " + compartments[intFlag]);
                                        gotoxy(20, 27);
                                        Console.Write("Enter 'return' to go back to previous screen");
                                        gotoxy(20, 20);
                                        Console.Write("Enter the compartment of the train in which you want to sit in :");
                                        compartmentsCheck = Console.ReadLine();
                                        flag = isSelectedCompartmentValid(trainCheck, compartmentsCheck);
                                        compartmentsCheck = conversion(compartmentsCheck);
                                        if (compartmentsCheck == "RETURN") // to go back to previous options
                                            break;
                                        if (flag == false)
                                        {
                                            gotoxy(20, 30);
                                            Console.Write("Invalid compartment !!");
                                            Console.ReadKey();
                                            continue;
                                        }
                                        gotoxy(20, 30);
                                        Console.Write("                                                          ");
                                        gotoxy(20, 31);
                                        Console.Write("                                                                                   ");

                                        while (true)
                                        {
                                            panel();

                                            gotoxy(70, 18);
                                            Console.Write("*****Passener's Menu*****");

                                            gotoxy(20, 25);
                                            Console.Write("if your luggage exceeds " + luggageTax[intFlag] + " kg, tax of 20% of total bill will be applied");
                                            gotoxy(20, 26);
                                            Console.Write("You can carry maximum 50 kg luggage with you");
                                            gotoxy(20, 27);
                                            Console.Write("Enter 'return' to go back to previous screen");
                                            gotoxy(20, 20);
                                            Console.Write("Enter the amount of luggage you want to carry with :");
                                            luggageTaxCheck = Console.ReadLine();
                                            flag = isLuggageInNumbers(luggageTaxCheck);
                                            luggageTaxCheck = conversion(luggageTaxCheck);
                                            if (luggageTaxCheck == "RETURN") // to go back to previous options
                                                break;
                                            if (flag == false)
                                            {
                                                gotoxy(20, 30);
                                                Console.Write(" Invalid luggage amount !!");
                                                Console.ReadKey();
                                                continue;
                                            }
                                            else if (int.Parse(luggageTaxCheck) > 50)
                                            {
                                                gotoxy(20, 30);
                                                Console.Write(" You can't carry more than 50kg with you !!");
                                                Console.ReadKey();
                                                continue;
                                            }

                                            while (true)
                                            {
                                                panel();

                                                gotoxy(70, 18);
                                                Console.Write("*****Passenger's Menu*****");

                                                totalBill = bill(trainCheck, ticketsDiscountCheck, luggageTaxCheck, compartmentsCheck);
                                                check = true;

                                                gotoxy(20, 29);
                                                Console.Write("Enter 'return' to go back to main screen of user panel");
                                                gotoxy(20, 27);
                                                Console.Write("Enter the amount : ");
                                                receivedAmount = Console.ReadLine();
                                                receivedAmount = conversion(receivedAmount);
                                                flag = isReceivedAmountCorrect(receivedAmount);
                                                if (receivedAmount == "RETURN") // to go back to previous options
                                                    break;

                                                if (flag == false)
                                                {
                                                    gotoxy(20, 31);
                                                    Console.Write(" Invalid amount !");
                                                    Console.ReadKey();
                                                    continue;
                                                }
                                                else if (totalBill > int.Parse(receivedAmount))
                                                {
                                                    gotoxy(20, 31);
                                                    Console.Write(" Your given amount is not enough !");
                                                    Console.ReadKey();
                                                    continue;
                                                }
                                                else
                                                {
                                                    gotoxy(20, 28);
                                                    Console.Write(" your cashback is : " + (int.Parse(receivedAmount) - totalBill));

                                                    gotoxy(70, 33);
                                                    Console.Write("Thank you!");
                                                    Console.ReadKey();
                                                    storeUserTravelingHistory(checkName, trainCheck, startingInput, destinationInput, ticketsDiscountCheck, compartmentsCheck, luggageTaxCheck, totalBill);
                                                    break;
                                                }
                                            }
                                            if (check == true)
                                                break;
                                        }
                                        if (check == true)
                                            break;
                                    }
                                    if (check == true)
                                        break;
                                }
                            }
                            gotoxy(20, 30);
                            Console.Write("Press any key to return");
                            Console.ReadKey();
                        }
                    }
                }
                else if (option[0] == '2') // sign up options
                {
                    checkName = signUp();

                    flag = isUserNameValid(checkName);
                    commaFlag = commaCheck(checkName);
                    if (flag == false)
                    {
                        gotoxy(20, 24);
                        Console.Write("User Already exists!");
                        Console.ReadKey();
                        continue;
                    }
                    else if (commaFlag == false)
                    {
                        gotoxy(20, 24);
                        Console.Write("Comma can not be used in username!");
                        Console.ReadKey();
                        continue;
                    }
                    else if (checkName.Length < 5)
                    {
                        gotoxy(20, 24);
                        Console.Write("username should atleast have length of 5!");
                        Console.ReadKey();
                        continue;
                    }

                    gotoxy(20, 21);
                    Console.Write("Enter your password :");
                    checkPassword = Console.ReadLine();

                    flag = passwordValidity(checkPassword);
                    commaFlag = commaCheck(checkPassword);
                    if (flag == false)
                    {
                        gotoxy(20, 24);
                        Console.Write("Password should atleast have length of 8 !!");
                        Console.ReadKey();
                        continue;
                    }
                    else if (commaFlag == false)
                    {
                        gotoxy(20, 24);
                        Console.Write("comma can not be used in password!!");
                        Console.ReadKey();
                        continue;
                    }

                    gotoxy(20, 22);
                    Console.Write("Enter your role :");
                    checkRole = Console.ReadLine();
                    checkRole = conversion(checkRole);

                    if (checkRole != "ADMIN" && checkRole != "USER")
                    {
                        gotoxy(20, 24);
                        Console.Write("Invalid role!!");
                        gotoxy(20, 25);
                        Console.Write("role should be admin or user!!");
                        continue;
                    }

                    gotoxy(20, 26);
                    Console.Write("User has been added successfully...");
                    names[count] = checkName;
                    passwords[count] = checkPassword;
                    role[count] = checkRole;
                    storeAccounts(checkName, checkPassword, checkRole);
                    count++;
                    Console.ReadKey();
                }
                else // program terminating condition
                {
                    return 0;
                }


            }
        }
        static void panel()
        {
            Console.Clear();
            Console.WriteLine("***************************************************************************************************************************************************************************");
            Console.WriteLine("                                                                                                                                                                     ");
            Console.WriteLine("           ________                  __                  __       __                                                                                        __       ");
            Console.WriteLine("          /        |                /  |                /  \\     /  |                                                                                      /  |      ");
            Console.WriteLine("          ********/______   ______  **/  _______        **  \\   /** |  ______   _______    ______    ______    ______   _____  ____    ______   _______   _** |_     ");
            Console.WriteLine("            ** | /      \\ /      \\ /  |/       \\       ***  \\ /*** | /      \\ /       \\  /      \\  /      \\  /      \\ /     \\/    \\  /      \\ /       \\ / **   |     ");
            Console.WriteLine("            ** |/******  |******  |** |*******  |      ****  /**** | ******  |*******  | ******  |/******  |/******  |****** ****  |/******  |*******  |******/      ");
            Console.WriteLine("            ** |** |  **/ /    ** |** |** |  ** |      ** ** **/** | /    ** |** |  ** | /    ** |** |  ** |**    ** |** | ** | ** |**    ** |** |  ** |  ** | __    ");
            Console.WriteLine("            ** |** |     /******* |** |** |  ** |      ** |***/ ** |/******* |** |  ** |/******* |** \\__** |********/ ** | ** | ** |********/ ** |  ** |  ** |/  |   ");
            Console.WriteLine("            ** |** |     **    ** |** |** |  ** |      ** | */  ** |**    ** |** |  ** |**    ** |**    ** |**       |** | ** | ** |**       |** |  ** |  **  **/    ");
            Console.WriteLine("            **/ **/       *******/**/ **/    **/       **/      **/  *******/ **/   **/  *******/  ******* | *******/ **/  **/  **/  *******/ **/   **/    ****/     ");
            Console.WriteLine("                                                                                                  /  \\__** |                                                               ");
            Console.WriteLine("                                                                                                  **    **/                                                                ");
            Console.WriteLine("                                                                                                   ******/                                                                 ");
            Console.WriteLine("***************************************************************************************************************************************************************************");
            Console.WriteLine("___________________________________________________________________________________________________________________________________________________________________________");
        }
        static void gotoxy(int x, int y)
        {
            Console.SetCursorPosition(x, y);
        }
        static string menu()
        {
            string option;
            gotoxy(75, 18);
            Console.Write("*****MENU*****");
            gotoxy(20, 20);
            Console.Write("Enter 1 to login ");
            gotoxy(20, 21);
            Console.Write("Enter 2 to SignUP ");
            gotoxy(20, 22);
            Console.Write("Enter 3 to exit program ");

            gotoxy(20, 24);
            Console.Write("Enter your choice : ");
            option = Console.ReadLine();

            return option;
        }
        static bool menuValidity(string option)
        {
            bool flag = false;

            if (option == "1" || option == "2" || option == "3")
            {
                flag = true;
            }
            return flag;
        }
        static int loginValidity(string checkName, string checkPassword)
        {
            int flag = 0;
            int COUNT = 0;
            for (int i = 0; i < total; i++)
            {
                if (checkName == names[i] && checkPassword == passwords[i])
                {
                    if (role[i] == "ADMIN" || role[i] == "USER")
                    {
                        COUNT++;
                        flag = i;
                        break;
                    }
                }
            }
            if (COUNT == 0)
                flag = -1;

            return flag;
        }
        static void storeAccounts(string userName, string password, string role)
        {
            string path = "accounts.txt";

            StreamWriter file = new StreamWriter(path,true);

            file.WriteLine( "{0},{1},{2}",userName, password, role);
            file.Flush();
            file.Close();
        }
        static string parsing(string record, int field)
        {
            int comma = 1;
            string item = "";
            for (int x = 0; x < record.Length; x++)
            {
                if (record[x] == ',')
                {
                    comma++;
                }
                else if (comma == field)
                {
                    item = item + record[x];
                }
            }
            return item;
        }
        static string signUp()
        {
            string checkName;
            panel();
            gotoxy(70, 18);
            Console.Write("*****SignUp Menu*****");

            gotoxy(20, 20);
            Console.Write("Enter your name :");
            checkName = Console.ReadLine();

            return checkName;
        }
        static bool isUserNameValid(string checkName)
        {
            bool flag = true;
            for (int i = 0; i < total; i++)
            {
                if (checkName == names[i])
                {
                    flag = false;
                    break;
                }
            }
            return flag;
        }
        static bool passwordValidity(string password)
        {
            bool flag = true;
            int leng = password.Length;

            if (leng < 8)
                flag = false;

            return flag;
        }
        static bool commaCheck(string input)
        {
            bool flag = true;
            int leng = input.Length;
            for (int i = 0; i < leng; i++)
            {
                if (input[i] == ',')
                {
                    flag = false;
                    break;
                }
            }
            return flag;
        }
        static string conversion(string line)
        {
            line = line.ToUpper();
            return line;
        }
        static string adminMenu()
        {
            string option;
            panel();

            gotoxy(70, 18);
            Console.Write("*****Manager's Menu*****");
            gotoxy(20, 20);
            Console.Write("Enter 1 to add a new train           ");
            gotoxy(20, 21);
            Console.Write("Enter 2 to search a train by its name");
            gotoxy(20, 22);
            Console.Write("Enter 3 to remove a train");
            gotoxy(20, 23);
            Console.Write("Enter 4 to change the class of train");
            gotoxy(20, 24);
            Console.Write("Enter 5 to change the time of departure of a train");
            gotoxy(20, 25);
            Console.Write("Enter 6 to change the price of a ticket");
            gotoxy(20, 26);
            Console.Write("Enter 7 to change number of compartments of a train");
            gotoxy(20, 27);
            Console.Write("Enter 8 to change the tax on luggage");
            gotoxy(20, 28);
            Console.Write("Enter 9 to change number of tickets to avail discount");
            gotoxy(20, 29);
            Console.Write("Enter 0 to view the travelling history of users.");
            gotoxy(20, 31);
            Console.Write("Enter 'return' to logout from admin panel.");
            gotoxy(20, 32);
            Console.Write("Enter your choice :");
            option = Console.ReadLine();

            return option;
        }
        static char adminMenuValidity(string option)
        {
            int n;
            bool flag = false;
            char value = ' ';

            n = option.Length;

            for (char i = '0'; i <= '9'; i++)
            {
                if (option[0] == i)
                {
                    value = i;
                    flag = true;
                }
            }

            if (n != 1 || flag == false)
            {
                value = ',';
            }

            return value;
        }
        static string addTrain()
        {
            string trainCheck;

            panel();

            gotoxy(70, 18);
            Console.Write("*****Manager's Menu*****");

            gotoxy(20, 20);
            Console.Write("Welcome to train adding section");

            gotoxy(20, 22);
            Console.Write("Enter the name of new train :");
            trainCheck = Console.ReadLine();
            trainCheck = conversion(trainCheck);

            return trainCheck;
        }
        static bool isTrainNameValid(string trainCheck)
        {
            bool flag = true;

            for (int i = 0; i < total; i++)
            {
                if (trainCheck == train[i])
                {
                    flag = false;
                    break;
                }
            }
            return flag;
        }
        static bool isTrainTypeValid(string trainType)
        {
            bool flag = false;
            if (trainType == "BUSINESS" || trainType == "ECONOMICAL" || trainType == "FIRSTCLASS")
            {
                flag = true;
            }
            return flag;
        }
        static bool compareClasses(string trainType, string preType)
        {
            bool flag = false;
            if (((trainType == "BUSINESS" || trainType == "ECONOMICAL" || trainType == "FIRSTCLASS")) && (trainType != preType))
            {
                flag = true;
            }
            return flag;
        }
        static int isTrainPriceValid(string trainPrice)
        {
            int COUNT = 0;
            int check = -1;
            int leng = trainPrice.Length;

            for (int j = 0; j < leng; j++)
            {
                for (char i = '0'; i <= '9'; i++)
                {
                    if (i == trainPrice[j])
                    {
                        COUNT++;
                    }
                }
            }
            if (COUNT == leng)
            {
                COUNT = int.Parse(trainPrice);
                if (COUNT >= 500 && COUNT <= 5000)
                    check = 1;
            }
            else
            {
                check = -1;
            }
            return check;
        }
        static bool isDepartureTimeValid(string trainDeparture)
        {

            int COUNT = 0;
            int len = trainDeparture.Length;

            if ((trainDeparture[0] >= '0' && trainDeparture[0] <= '9'))
            {
                if (trainDeparture[0] <= '2')
                    COUNT++;
            }
            if ((trainDeparture[1] >= '0' && trainDeparture[1] <= '9'))
            {
                if (trainDeparture[0] == '2' && trainDeparture[1] <= '3')
                    COUNT++;
                if (trainDeparture[0] != '2' && trainDeparture[1] <= '9')
                    COUNT++;
            }
            if (trainDeparture[2] == ':')
            {
                COUNT++;
            }
            if ((trainDeparture[3] >= '0' && trainDeparture[3] <= '9'))
            {
                if (trainDeparture[3] <= '5')
                    COUNT++;
            }
            if ((trainDeparture[4] >= '0' && trainDeparture[4] <= '9'))
            {
                COUNT++;
            }

            if (len != 5 || COUNT != 5)
                return false;
            else
                return true;
        }
        static bool isTrainCompartmentValid(string trainCompartment)
        {
            int COUNT = 0;
            bool flag = false;

            int leng = trainCompartment.Length;

            for (int i = 0; i < 2; i++)
            {
                for (char j = '0'; j <= '9'; j++)
                {
                    if (trainCompartment[i] == j)
                        COUNT++;
                }
            }
            if (COUNT == leng)
            {
                COUNT = int.Parse(trainCompartment);
                if (COUNT > 9 && COUNT < 21)
                    flag = true;
            }
            return flag;
        }
        static bool isTrainDiscountValid(string trainDiscount)
        {
            bool flag = false;
            int leng = trainDiscount.Length;

            for (char i = '1'; i <= '9'; i++)
            {
                if (trainDiscount[0] == i)
                    flag = true;
            }

            if (leng == 1 && flag == true)
                return true;
            else
                return false;
        }
        static bool isTrainLuggageValid(string trainLuggage)
        {
            bool flag = false;
            int check = 0;
            int leng = trainLuggage.Length;

            for (int i = 0; i < leng; i++)
            {
                for (char j = '0'; j <= '9'; j++)
                {
                    if (trainLuggage[i] == j)
                        check++;
                }
            }
            if (check == leng)
            {
                check = int.Parse(trainLuggage);
                if (check > 0 && check <= 30)
                    flag = true;
            }

            return flag;
        }
        static bool isTrainStartValid(string trainStart)
        {
            bool flag = false;

            if (trainStart == "LAHORE" || trainStart == "KARACHI" || trainStart == "ISLAMABAD" || trainStart == "MULTAN" || trainStart == "PESHAWAR" || trainStart == "QUETTA" || trainStart == "GUJRANWALA" || trainStart == "HAIDERABAD" || trainStart == "SIALKOT")
            {
                flag = true;
            }
            return flag;
        }
        static bool isTrainEndValid(string trainStart, string trainEnd)
        {
            bool flag = false;

            if (trainEnd == "LAHORE" || trainEnd == "KARACHI" || trainEnd == "ISLAMABAD" || trainEnd == "MULTAN" || trainEnd == "PESHAWAR" || trainEnd == "QUETTA" || trainEnd == "GUJRANWALA" || trainEnd == "HAIDERABAD" || trainEnd == "SIALKOT")
            {

                if (trainStart != trainEnd)
                    flag = true;
            }
            return flag;
        }
        static string searchTrain()
        {
            string trainCheck;
            panel();

            gotoxy(70, 18);
            Console.Write("*****Manager's Menu*****");

            gotoxy(20, 20);
            Console.Write("Welcome to Searching Section ");

            gotoxy(20, 22);
            Console.Write("Enter the name of train you want to search :");
            trainCheck = Console.ReadLine();
            trainCheck = conversion(trainCheck);

            return trainCheck;
        }
        static int searchTrainValidity(string trainCheck)
        {
            int flag = -1;
            for (int i = 0; i < total; i++)
            {
                if (trainCheck == train[i])
                {
                    flag = i;
                    break;
                }
            }
            return flag;
        }
        static void DisplaySearchTrain(int trainIndex)
        {
            panel();

            gotoxy(70, 18);
            Console.Write("*****Manager's Menu*****");

            gotoxy(20, 20);
            Console.Write("Welcome to Searching Section ");
            gotoxy(20, 22);
            Console.Write("Required train is : " + train[trainIndex]);
            gotoxy(20, 23);
            Console.Write("The class of this train is : " + type[trainIndex]);
            gotoxy(20, 24);
            Console.Write("The time of departure of this train is : " + departureTime[trainIndex]);
            gotoxy(20, 25);
            Console.Write("The number of compartments of this train is : " + compartments[trainIndex]);
            gotoxy(20, 26);
            Console.Write("The price of ticket of this train is : " + ticketPrice[trainIndex]);
            gotoxy(20, 27);
            Console.Write("The minimum number of tickets to avail discount are : " + ticketsDiscount[trainIndex]);
            gotoxy(20, 28);
            Console.Write("The minimum amount of luggage to apply tax is  : " + luggageTax[trainIndex]);
            gotoxy(20, 29);
            Console.Write("The starting point of the train is : " + starting[trainIndex]);
            gotoxy(20, 30);
            Console.Write("The destination of the train is  : " + ending[trainIndex]);
            Console.ReadKey();
        }
        static string removeTrain()
        {
            string trainCheck;
            Console.Clear();
            panel();

            gotoxy(70, 18);
            Console.Write("*****Manager's Menu*****");

            gotoxy(20, 20);
            Console.Write("Welcome to train deleting section");

            gotoxy(20, 22);
            Console.Write("Enter the name of the train you want to delete :");
            trainCheck = Console.ReadLine();
            trainCheck = conversion(trainCheck);

            return trainCheck;
        }
        static void removeTrainExecute(string trainCheck)
        {
            int temp = 0;
            for (int i = 0; i < total; i++)
            {
                if (trainCheck == train[i])
                {
                    temp = i;
                    break;
                }
            }
            for (int j = temp; j < total-1; j++)
            {
                train[j] = train[j + 1];
                type[j] = type[j + 1];
                ticketPrice[j] = ticketPrice[j + 1];
                departureTime[j] = departureTime[j + 1];
                compartments[j] = compartments[j + 1];
                ticketsDiscount[j] = ticketsDiscount[j + 1];
                starting[j] = starting[j + 1];
                ending[j] = ending[j + 1];
            }
            cycle--;
            deleteTrainData();
        }
        static string classTrain()
        {
            string trainCheck;
            Console.Clear();
            panel();

            gotoxy(70, 18);
            Console.Write("*****Manager's Menu*****");

            gotoxy(20, 20);
            Console.Write("Welcome to train class change section");

            gotoxy(20, 22);
            Console.Write("Enter the name of the train whose class you want to change :");
            trainCheck = Console.ReadLine();
            trainCheck = conversion(trainCheck);

            return trainCheck;
        }
        static string previousClass(string trainCheck)
        {
            string temp = "";
            for (int i = 0; i < total; i++)
            {
                if (trainCheck == train[i])
                {
                    temp = type[i];
                    break;
                }
            }
            return temp;
        }
        static void classAssign(string trainCheck, string currentClass)
        {
            int temp;
            for (int i = 0; i < total; i++)
            {
                if (trainCheck == train[i])
                {
                    type[i] = currentClass;
                }
            }
            updateInFile();
        }
        static string departure()
        {
            string trainCheck;

            panel();

            gotoxy(70, 18);
            Console.Write("*****Manager's Menu*****");

            gotoxy(20, 20);
            Console.Write("Welcome to train departure time change section");

            gotoxy(20, 22);
            Console.Write("Enter the name of the train whose departure time you want to change :");
            trainCheck = Console.ReadLine();
            trainCheck = conversion(trainCheck);

            return trainCheck;
        }
        static string previousTime(string trainCheck)
        {
            string temp = "";
            for (int i = 0; i < total; i++)
            {
                if (trainCheck == train[i])
                {
                    temp = departureTime[i];
                    break;
                }
            }
            return temp;
        }
        static void timeAssign(string trainCheck, string preTime)
        {
            for (int i = 0; i < total; i++)
            {
                if (trainCheck == train[i])
                {
                    departureTime[i] = preTime;
                }
            }
            updateInFile();
        }
        static string price()
        {
            string trainCheck;
            panel();

            gotoxy(70, 18);
            Console.Write("*****Manager's Menu*****");

            gotoxy(20, 20);
            Console.Write("Welcome to train's ticket price change section");

            gotoxy(20, 32);
            Console.Write("Minimum 500 and maximum 5000!!");
            gotoxy(20, 22);
            Console.Write("Enter the name of the train whose ticket price you want to change :");
            trainCheck = Console.ReadLine();
            trainCheck = conversion(trainCheck);

            return trainCheck;
        }
        static string previousPrice(string trainCheck)
        {
            string temp = "";
            for (int i = 0; i < total; i++)
            {
                if (trainCheck == train[i])
                {
                    temp = ticketPrice[i];
                    break;
                }
            }
            return temp;
        }
        static void priceAssign(string trainCheck, string prePrice)
        {
            for (int i = 0; i < total; i++)
            {
                if (trainCheck == train[i])
                {
                    ticketPrice[i] = prePrice;
                }
            }
            updateInFile();
        }
        static string compartment()
        {
            string trainCheck;
            Console.Clear();
            panel();

            gotoxy(70, 18);
            Console.Write("*****Manager's Menu*****");

            gotoxy(20, 32);
            Console.Write("Minimum 10 and Maximum 20");
            gotoxy(20, 20);
            Console.Write("Welcome to train's compartment changing section");
            gotoxy(20, 22);
            Console.Write("Enter the name of the train whose compartments you want to change :");
            trainCheck = Console.ReadLine();
            trainCheck = conversion(trainCheck);

            return trainCheck;
        }
        static string previousCompartment(string trainCheck)
        {
            string temp = "";
            for (int i = 0; i < total; i++)
            {
                if (trainCheck == train[i])
                {
                    temp = compartments[i];
                    break;
                }
            }
            return temp;
        }
        static void compartmentAssign(string trainCheck, string preCompartment)
        {
            for (int i = 0; i < total; i++)
            {
                if (trainCheck == train[i])
                {
                    compartments[i] = preCompartment;
                }
            }
            updateInFile();
        }
        static string luggage()
        {
            string trainCheck;
            panel();

            gotoxy(70, 18);
            Console.Write("*****Manager's Menu*****");

            gotoxy(20, 20);
            Console.Write("Welcome to train's applying tax changing section");
            gotoxy(20, 22);
            Console.Write("Enter the name of the train whose amount of luggage for applying tax you want to change :");
            trainCheck = Console.ReadLine();
            trainCheck = conversion(trainCheck);

            return trainCheck;
        }
        static string previousLuggage(string trainCheck)
        {
            string temp = "";
            for (int i = 0; i < total; i++)
            {
                if (trainCheck == train[i])
                {
                    temp = luggageTax[i];
                    break;
                }
            }
            return temp;
        }
        static void luggageAssign(string trainCheck, string preLuggage)
        {
            for (int i = 0; i < total; i++)
            {
                if (trainCheck == train[i])
                {
                    luggageTax[i] = preLuggage;
                }
            }
            updateInFile();
        }
        static string discount()
        {
            string trainCheck;
            panel();

            gotoxy(70, 18);
            Console.Write("*****Manager's Menu*****");

            gotoxy(20, 20);
            Console.Write("Welcome to train's discount availing section");

            gotoxy(20, 22);
            Console.Write("Enter the name of the train whose discount availing tickets you want to change :");
            trainCheck = Console.ReadLine();
            trainCheck = conversion(trainCheck);

            return trainCheck;
        }
        static string previousDiscount(string trainCheck)
        {
            string temp = "";
            for (int i = 0; i < total; i++)
            {
                if (trainCheck == train[i])
                {
                    temp = ticketsDiscount[i];
                    break;
                }
            }
            return temp;
        }
        static void discountAssign(string trainCheck, string preDiscount)
        {
            for (int i = 0; i < total; i++)
            {
                if (trainCheck == train[i])
                {
                    ticketPrice[i] = preDiscount;
                }
            }
            updateInFile();
        }

        static string user()
        {
            string choice;
            panel();

            gotoxy(70, 18);
            Console.Write("*****Passener's Menu*****");

            gotoxy(20, 20);
            Console.Write("Enter 1 for purchasing tickets and sheduling departure");
            gotoxy(20, 21);
            Console.Write("Enter 2 for viewing your travelling history");
            gotoxy(20, 22);
            Console.Write("Enter 0 to logout from user panel");
            gotoxy(20, 25);
            Console.Write("Enter your choice :");
            choice = Console.ReadLine();

            return choice;
        }
        static string startingPoint()
        {
            string startingInput;
            panel();

            gotoxy(80, 24);
            Console.Write("Available Stations");
            gotoxy(20, 26);
            Console.Write("Lahore");
            gotoxy(50, 26);
            Console.Write("Karachi");
            gotoxy(80, 26);
            Console.Write("Islamabad");
            gotoxy(110, 26);
            Console.Write("Multan");
            gotoxy(140, 26);
            Console.Write("Quetta");
            gotoxy(20, 27);
            Console.Write("Sialkot");
            gotoxy(50, 27);
            Console.Write("Peshawar");
            gotoxy(80, 27);
            Console.Write("Haiderabad");
            gotoxy(110, 27);
            Console.Write("Gujranwala");
            gotoxy(70, 18);
            Console.Write("*****Passener's Menu*****");

            gotoxy(20, 20);
            Console.Write("Enter your starting point :");
            startingInput = Console.ReadLine();
            startingInput = conversion(startingInput);

            return startingInput;
        }
        static string destinationPoint()
        {
            string destinationInput;
            panel();

            gotoxy(80, 24);
            Console.Write("Available Stations");
            gotoxy(20, 26);
            Console.Write("Lahore");
            gotoxy(50, 26);
            Console.Write("Karachi");
            gotoxy(80, 26);
            Console.Write("Islamabad");
            gotoxy(110, 26);
            Console.Write("Multan");
            gotoxy(140, 26);
            Console.Write("Quetta");
            gotoxy(20, 27);
            Console.Write("Sialkot");
            gotoxy(50, 27);
            Console.Write("Peshawar");
            gotoxy(80, 27);
            Console.Write("Haiderabad");
            gotoxy(110, 27);
            Console.Write("Gujranwala");

            gotoxy(70, 18);
            Console.Write("*****Passener's Menu*****");

            gotoxy(20, 20);
            Console.Write("Enter your destination :");
            destinationInput = Console.ReadLine();
            destinationInput = conversion(destinationInput);

            return destinationInput;
        }
        static void selectClass()
        {
            panel();

            gotoxy(70, 18);
            Console.Write("*****Passener's Menu*****");
            gotoxy(20, 20);
            Console.Write("BUSINESS , ECONOMICAL , FIRSTCLASS  ");
            gotoxy(20, 22);
        }
        static bool availableTrains(string startingInput, string destinationInput)
        {
            panel();
            gotoxy(70, 18);
            Console.Write("*****Passener's Menu*****");
            int COUNT = 0;

            sort();
            for (int i = 0; i < total; i++)
            {
                if (startingInput == starting[i] && destinationInput == ending[i])
                {
                    gotoxy(20, COUNT + 28);
                    Console.Write(departureTime[i]);
                    gotoxy(38, COUNT + 28);
                    Console.Write(type[i]);
                    gotoxy(53, COUNT + 28);
                    Console.Write(ticketPrice[i]);
                    gotoxy(70, COUNT + 28);
                    Console.Write(starting[i]);
                    gotoxy(85, COUNT + 28);
                    Console.Write(ending[i]);
                    gotoxy(104, COUNT + 28);
                    Console.Write(train[i]);
                    COUNT++;
                }
            }

            if (COUNT != 0)
            {
                gotoxy(20, 26);
                Console.Write("DepartureTime       Type      TicketPrice        Starting        Destination        Train");
                return true;
            }
            else
            {
                gotoxy(20, 29);
                Console.Write("No such train available which fulfills your requirement!!");
                return false;
            }
        }
        static bool isSelectedTrainValid(string trainName, string startingInput, string destinationInput)
        {
            bool flag = false;

            for (int i = 0; i < total; i++)
            {
                if (trainName == train[i] && startingInput == starting[i] && destinationInput == ending[i])
                {
                    flag = true;
                }
            }
            return flag;
        }
        static int currentTrainIndex(string trainCheck)
        {
            int temp = -1;
            for (int i = 0; i < total; i++)
            {
                if (train[i] == trainCheck)
                {
                    temp = i;
                    break;
                }
            }
            return temp;
        }
        static bool isSelectedCompartmentValid(string trainCheck, string trainCompartment)
        {
            int COUNT = 0;
            int temp = 0;

            for (int i = 0; i < total; i++)
            {
                if (train[i] == trainCheck)
                {
                    temp = i;
                }
            }

            int leng = trainCompartment.Length;

            for (int i = 0; i < leng; i++)
            {
                for (char j = '0'; j <= '9'; j++)
                {
                    if (trainCompartment[i] == j)
                    {
                        COUNT++;
                    }
                }
            }

            if (leng <= 2 && COUNT == leng)
            {
                COUNT = int.Parse(trainCompartment);
                temp = int.Parse(compartments[temp]);

                if (COUNT <= temp && COUNT != 0)
                    return true;
                else
                    return false;
            }
            else
                return false;
        }
        static bool isLuggageInNumbers(string luggageTaxCheck)
        {
            int COUNT = 0;
            int leng = luggageTaxCheck.Length;

            for (int i = 0; i < leng; i++)
            {
                for (char j = '0'; j <= '9'; j++)
                {
                    if (luggageTaxCheck[i] == j)
                    {
                        COUNT++;
                    }
                }
            }
            if (leng == COUNT)
                return true;
            else
                return false;
        }
        static bool isReceivedAmountCorrect(string receivedAmount)
        {
            bool flag = false;
            int leng = receivedAmount.Length;
            int COUNT = 0;

            for (int i = 0; i < leng; i++)
            {
                for (char j = '0'; j <= '9'; j++)
                {
                    if (receivedAmount[i] == j)
                        COUNT++;
                }
            }

            if (leng == COUNT)
                flag = true;

            return flag;
        }
        static int bill(string trainCheck, string ticketsDiscountCheck, string luggageTaxCheck, string compartmentsCheck)
        {
            int tic;
            int ticDis;
            int ticPrice;
            int lug;
            int lugDis;
            int temp = 0;
            int result;

            for (int i = 0; i < total; i++)
            {
                if (trainCheck == train[i])
                {
                    temp = i;
                    break;
                }
            }

            ticPrice = int.Parse(ticketPrice[temp]);
            tic = int.Parse(ticketsDiscountCheck);
            lug = int.Parse(luggageTaxCheck);
            ticDis = int.Parse(ticketsDiscount[temp]);
            lugDis = int.Parse(luggageTax[temp]);

            ticPrice = ticPrice * tic;

            if (tic >= ticDis)
            {   
                ticPrice = ticPrice - (int)(ticPrice * 0.3);
            }
            result = ticPrice;
            if (lug >= lugDis)
            {
                result = ticPrice + (int)(ticPrice * 0.2);
            }

            gotoxy(20, 20);
            Console.Write("Your total payable amount is :" + result);
            gotoxy(20, 21);
            Console.Write("Your train's name is :" + trainCheck);
            gotoxy(20, 22);
            Console.Write("The class of the train is :" + type[temp]);
            gotoxy(20, 23);
            Console.Write("Your starting station is :" + starting[temp]);
            gotoxy(20, 24);
            Console.Write("Your destination is :" + ending[temp]);
            gotoxy(20, 25);
            Console.Write("Your selected compartment number is :" + compartmentsCheck);

            return result;
        }

        static void sort()
        {
            string tempTrain;
            string tempType;
            string tempTicketPrice;
            string tempDepartureTime;
            string tempCompartments;
            string tempTicketsDiscount;
            string tempLuggageTax;
            string tempStarting;
            string tempEnding;

            int temp1;
            int temp2;

            for (int i = 0; i < cycle; i++)
            {
                for (int j = i + 1; j < cycle; j++)
                {
                    temp1 = int.Parse(ticketPrice[i]);
                    temp2 = int.Parse(ticketPrice[j]);

                    if (temp1 > temp2)
                    {
                        tempTrain = train[i];
                        tempType = type[i];
                        tempTicketPrice = ticketPrice[i];
                        tempDepartureTime = departureTime[i];
                        tempCompartments = compartments[i];
                        tempTicketsDiscount = ticketsDiscount[i];
                        tempLuggageTax = luggageTax[i];
                        tempStarting = starting[i];
                        tempEnding = ending[i];

                        train[i] = train[j];
                        type[i] = type[j];
                        ticketPrice[i] = ticketPrice[j];
                        departureTime[i] = departureTime[j];
                        compartments[i] = compartments[j];
                        ticketsDiscount[i] = ticketsDiscount[j];
                        luggageTax[i] = luggageTax[j];
                        starting[i] = starting[j];
                        ending[i] = ending[j];

                        train[j] = tempTrain;
                        type[j] = tempType;
                        ticketPrice[j] = tempTicketPrice;
                        departureTime[j] = tempDepartureTime;
                        compartments[j] = tempCompartments;
                        ticketsDiscount[j] = tempTicketsDiscount;
                        luggageTax[j] = tempLuggageTax;
                        starting[j] = tempStarting;
                        ending[j] = tempEnding;
                    }
                }
            }
        }
        static string Parsing(string word, int location)
        {
            int commaCount = 1;
            string item = "";
            for (int x = 0; x < word.Length; x++)
            {
                if (word[x] == ',')
                {
                    commaCount = commaCount + 1;
                }
                else if (commaCount == location)
                {
                    item = item + word[x];
                }
            }
            return item;
        }
        static void displayUserTravelingHistory()
        {
            StreamReader file = new StreamReader("travellingHistory.txt");
            string word = "";

            while ((word = file.ReadLine()) != null)
            {
                if (word != "")
                {
                    Console.WriteLine(Parsing(word, 1) + " travelled from " + Parsing(word, 3) + " to " + Parsing(word, 4)
                         + " using " + Parsing(word, 2) + "(train name). He purchased " + Parsing(word, 5)
                         + " tickets and his total bill was " + Parsing(word, 8));
                }
            }
            file.Close();
            Console.Write("Enter any key to continue...");
            Console.ReadKey();
        }
        static void displaySpecificUserTravelingHistory(string userName)
        {
            StreamReader file = new StreamReader("travellingHistory.txt");
            string word = "";
            
            while ((word = file.ReadLine()) != null)
            {
                if (word != "" && Parsing(word, 1) == userName)
                {
                    Console.WriteLine("You travelled from " + Parsing(word, 3) + " to " + Parsing(word, 4)
                         + " using " + Parsing(word, 2) + "(train name). You purchased " + Parsing(word, 5)
                         + " tickets and your total bill was " + Parsing(word, 8));
                }
            }
            file.Close();
            Console.Write("Enter any key to continue...");
            Console.ReadKey();
        }
        static void storeUserTravelingHistory(string checkName, string trainCheck, string startingInput, string destinationInput, string ticketsDiscountCheck, string compartmentsCheck, string luggageTaxCheck, int totalBill)
        {
            StreamWriter file = new StreamWriter("travellingHistory.txt",true);

            file.WriteLine(  checkName + "," + trainCheck + "," + startingInput + "," + destinationInput + "," + ticketsDiscountCheck
                 + "," + compartmentsCheck + "," + luggageTaxCheck + "," + totalBill);

            file.Close();
        }
        static void storeTrainData(string trainCheck, string classCheck, string ticketPriceCheck, string departureTimeCheck, string compartmentsCheck, string ticketsDiscountCheck, string luggageTaxCheck, string startingCheck, string endingCheck)
        {
            StreamWriter file = new StreamWriter("adminData.txt", true);
 
            file.WriteLine( trainCheck + "," + classCheck + "," + ticketPriceCheck + "," + departureTimeCheck + "," + compartmentsCheck
                 + "," + ticketsDiscountCheck + "," + luggageTaxCheck + "," + startingCheck + "," + endingCheck );
            file.Close();
        }
        static void deleteTrainData()
        {
            StreamWriter file = new StreamWriter("adminData.txt");
      
            for (int i = 0; i < cycle - 1; i++)
            {
                file.WriteLine( train[i] + "," + type[i] + "," + ticketPrice[i] + "," + departureTime[i] + "," + compartments[i]
                     + "," + ticketsDiscount[i] + "," + luggageTax[i] + "," + starting[i] + "," + ending[i]);
            }
            file.Close();
        }
        static void updateInFile()
        {
            StreamWriter file = new StreamWriter("adminData.txt");
            
            for (int i = 0; i < cycle; i++)
            {
                file.WriteLine( train[i] + "," + type[i] + "," + ticketPrice[i] + "," + departureTime[i] + "," + compartments[i]
                     + "," + ticketsDiscount[i] + "," + luggageTax[i] + "," + starting[i] + "," + ending[i]);
            }
            file.Close();
        }
        static void loadingTrainData()
        {
            StreamReader file = new StreamReader("adminData.txt");
            string word;

            while ((word = file.ReadLine()) != null )
            {
                train[cycle] = Parsing(word, 1);
                type[cycle] = Parsing(word, 2);
                ticketPrice[cycle] = Parsing(word, 3);
                departureTime[cycle] = Parsing(word, 4);
                compartments[cycle] = Parsing(word, 5);
                ticketsDiscount[cycle] = Parsing(word, 6);
                luggageTax[cycle] = Parsing(word, 7);
                starting[cycle] = Parsing(word, 8);
                ending[cycle] = Parsing(word, 9);
                cycle++;
            }
            file.Close();
        }
        static void loadingAccounts()
        {
            string path = "accounts.txt";
            StreamReader file = new StreamReader(path);
            string record;
            while ((record = file.ReadLine()) != null)
            {
                names[count] = parsing(record, 1);
                passwords[count] = parsing(record, 2);
                role[count] = parsing(record, 3);
                count++;
            }
            file.Close();
        }
    }
}


