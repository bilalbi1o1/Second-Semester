﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace AllTasks
{
    class Program
    {
        static void Main(string[] args)
        {
            //Task1();
            //Task2();
            //Task3();
            //Task4();
            //Task5();
            //Task6();
            //Task7();
            //Task8();
            //Task9();
            //Task10();
            //Task11();
            //Task12();
            Task13();
        }
        //Basic Operations 
        static void Task1()
        {
            Console.WriteLine("Hello World");
            Console.Write("Hello World");
            Console.Read();
        }
        static void Task2()
        {
            float length;
            float area;
            string str;

            Console.WriteLine("Enter length : ");
            str = Console.ReadLine();
            length = float.Parse(str);
            area = length * length;
            Console.WriteLine("The area is :");
            Console.Write(area);
            Console.ReadKey();
        }
        
        //Conditional Statements and loops 
        static void Task3()
        {
            string input;
            float marks;
            Console.Write("Enter the Marks : ");
            input = Console.ReadLine();
            marks = float.Parse(input);
            if (marks > 50)
            {
                Console.WriteLine("You are passed");
            }
            else
                Console.WriteLine("You are failed");

            Console.ReadKey();


        }
        static void Task4()
        {
            for (int i = 0; i < 5; i++)
            {
                Console.WriteLine("Welcome Jack");
            }
            Console.Read();
        }
        static void Task5()
        {
            int num;
            int sum = 0;

            Console.Write("Enter Number : ");
            num = int.Parse(Console.ReadLine());
            while (num != -1)
            {
                sum = sum + num;
                Console.Write("Enter Number : ");
                num = int.Parse(Console.ReadLine());
            }
            Console.WriteLine("The total sum is {0} ",sum);
            Console.Read();
        }
        static void Task6()
        {
            int num;
            int sum = 0;

            do
            {
                Console.Write("Enter Number : ");
                num = int.Parse(Console.ReadLine());
                sum = sum + num;
            } 
            while (num != -1) ;
            sum = sum + 1;
            Console.WriteLine("The total sum is {0} ", sum);
            Console.Read();
        }
        static void Task7()
        {
            int[] numbers = new int[3];
            
            for (int i = 0; i < 3; i++)
            {
                Console.Write("Enter number ");
                numbers[i] = int.Parse(Console.ReadLine());
            }

            int largest = numbers[0];
            for (int i = 0; i < 3; i++)
            {
                if (numbers[i] > largest)
                {
                    largest = numbers[i];
                }
            }
            Console.Write("Largest number is {0}", largest);
            Console.ReadKey();
        }
        static void Task8()//Take away Task
        {
            int age;
            float eachToyPrice;
            float WashingMachinePrice;
            
            Console.Write("Enter the age of Lily : ");
            age = int.Parse(Console.ReadLine());
            Console.Write("Enter the price of each toy : ");
            eachToyPrice = float.Parse(Console.ReadLine());
            Console.Write("Enter the price of Washing Mashine : ");
            WashingMachinePrice = float.Parse(Console.ReadLine());

            float savedMoney = 0;
            float numberOfToys = 0;
            float birthdayMoney = 10; 

            for (int currentYear = 1; currentYear <= age; currentYear++)
            {
                if (currentYear % 2 == 0)
                {
                    savedMoney = savedMoney + birthdayMoney - 1;
                    birthdayMoney = birthdayMoney + 10;
                }
                else
                    numberOfToys++;
            }
            savedMoney = savedMoney + (numberOfToys* eachToyPrice);

            if (savedMoney >= WashingMachinePrice)
            {
                Console.Write("Yes! {0}", savedMoney - WashingMachinePrice);
            }
            else
            {
                Console.Write("No! {0}", WashingMachinePrice - savedMoney);
            }
            Console.ReadKey();
        }
        
        //Functions and File handling
        static void Task9()
        {
            int num1;
            int num2;

            Console.Write("Enter 1st number: ");
            num1 = int.Parse(Console.ReadLine());
            Console.Write("Enter 2nd number: "); 
            num2 = int.Parse(Console.ReadLine());

            int result = add(num1,num2);
            Console.WriteLine("Sum is {0}",result);
            Console.ReadKey();
        }
        static int add(int num1,int num2)
        {
            return num1 + num2;
        }
        
        static void Task10()
        {
            string path = "D:\\Bilal\\work\\OOP\\Week1 Lab\\check.txt";
            if (File.Exists(path))
            {
                StreamReader file = new StreamReader(path);
                string record;
                while ((record = file.ReadLine()) != null)
                {
                    Console.WriteLine(record);
                }
                file.Close();
            }
            else 
            {
                Console.Write("Not Exist");
            }
            Console.ReadKey();
        }
        static void Task11()
        {
            string path = "D:\\Bilal\\work\\OOP\\Week1 Lab\\check.txt";

                StreamWriter file = new StreamWriter(path,true);
                file.WriteLine("Complete");
                file.Flush();
                file.Close();
        }
        
        static void Task12()//Sign in / sign up application
        { 
            string path = "D:\\Bilal\\work\\OOP\\Week1 Lab\\SignIn.txt";
            string[] names = new string[5];
            string[] password = new string[5];

            int option;
            do
            {
                readData(path, names, password);
                Console.Clear();
                option = menu();
                Console.Clear();
                if (option == 1)
                {
                    Console.WriteLine("Enter Name: ");
                    string n = Console.ReadLine();
                    Console.WriteLine("Enter Password: ");
                    string p = Console.ReadLine();
                    signIn(n, p, names, password);
                }
                else
                {
                    Console.WriteLine("Enter New Name: ");
                    string n = Console.ReadLine();
                    Console.WriteLine("Enter New Password: ");
                    string p = Console.ReadLine();
                    signUp(path, n, p);
                }
            }
            while (option < 3);
            Console.Read();
        }
        static int menu()
        {
            int option;
            Console.WriteLine("1. SignIn");
            Console.WriteLine("2. SignUp");
            Console.WriteLine("Enter Option : ");
            option = int.Parse(Console.ReadLine());
            return option;
        }
        static string parseData(string record, int field)
        {
            int comma = 1;
            string item = "";
            for (int x = 0; x < record.Length; x++)
            {
                if (record[x] == ',')
                {
                    comma++;
                }
                else if (comma == field)
                {
                    item = item + record[x];
                }
            }
            return item;
        }
        static void readData(string path,string[] names,string[] password)
        {
            int x = 0;
            if (File.Exists(path))
            {
                StreamReader file = new StreamReader(path);
                string record;
                while ((record = file.ReadLine()) != null)
                {
                    names[x] = parseData(record,1);
                    password[x] = parseData(record, 2);
                    x++;
                    if (x >= 5)
                        break;
                }
                file.Close();
            }
            else
            {
                Console.Write("Not Exist");
            }
            Console.ReadKey();

        }
        static void signIn(string n, string p, string[] names, string[] password)
        {
            bool flag = false;
            
            for (int i = 0; i < 5; i++)
            {
                if (n == names[i] && p == password[i])
                {
                    Console.WriteLine("Valid User");
                    flag = true;
                }
            }
            if (flag == false)
                Console.WriteLine("Invalid User");

            Console.ReadKey();
        }
        static void signUp(string path , string n , string p)
        {
            StreamWriter file = new StreamWriter(path,true);
            file.WriteLine(n + "," + p);
            file.Flush();
            file.Close();
        }

        static void Task13()//self assessment
        {
            string path = "D:\\Bilal\\work\\OOP\\Week1 Lab\\customers.txt";
            int minOrders;
            int minPrice;

            Console.Write("Enter minimum number of orders for eligibilty : ");
           minOrders = int.Parse(Console.ReadLine());
            Console.Write("Enter minimum price of orders for eligibilty : ");
            minPrice = int.Parse(Console.ReadLine());

            readCustomersData(path,minOrders,minPrice);
        }
        static void readCustomersData(string path,int minOrders,int minPrice)
        {
            string name;
            int numberOfOrders;
            int priceOfOrder;
            int loopCount = 0;
            int count = 0;
            int nameCount = 0;

            if (File.Exists(path))
            {
                StreamReader file = new StreamReader(path);
                string record;
                while ((record = file.ReadLine()) != null)
                {
                    name = parseData(record, 1);
                    numberOfOrders = int.Parse(parseData(record, 2));

                    while (loopCount <= numberOfOrders)
                    {
                        priceOfOrder = int.Parse(parseData(record,loopCount+2));
                        if (priceOfOrder > minPrice)
                            count++;
                        loopCount++;
                    }
                    if (count >= minOrders)
                    {
                        Console.WriteLine(name);
                        nameCount++;
                    }
                    count = 0;
                    loopCount = 0;
                }
                file.Close();
                if (nameCount == 0)
                    Console.WriteLine("Nobody is Eligible");
            }
            else
            {
                Console.Write("Not Exist");
            }
            Console.ReadKey();

        }
    }
}
